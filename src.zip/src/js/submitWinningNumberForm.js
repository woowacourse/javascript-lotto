import { $, $all } from '../util/selector.js';
import WinningLotto from '../domain/WinningLotto.js';
import Lotto from '../domain/Lotto.js';
import { parseWinningNumber, parseBonusNumber } from '../input/parseInput.js';
import { calculateMatchingResult } from '../service/MatchingService.js';
import { calculateProfitRate } from '../service/ProfitService.js';
import { showModal } from './util/modal.js';
import { resetError, showError } from './util/errorHandler.js';
import validateBonusNumber from '../validation/validateBonusNumber.js';
import validateWinningNumber from '../validation/validateWinningNumber.js';
import setupModalControl from './setupModalControl.js';
import updateMatchingResult from './view/updateMatchingResult.js';

export const submitWinningNumberForm = (lottoArray) => {
  $('.winning-form').addEventListener('submit', (event) => {
    event.preventDefault();
    const winningLotto = handleWinningNumber(lottoArray);

    const matchingResult = calculateMatchingResult(winningLotto, lottoArray);
    const profitRate = calculateProfitRate(matchingResult, lottoArray.length);

    updateMatchingResult(matchingResult, profitRate);
    showModal($('.modal'));
    setupModalControl();
  });
};

const handleWinningNumber = () => {
  const errorUI = $('.winning-form__error-message');
  resetError(errorUI);

  try {
    const { winningNumbers, bonusNumber } = getWinningNumbers();
    const winningLotto = new WinningLotto(new Lotto(winningNumbers), bonusNumber);
    return winningLotto;
  } catch (error) {
    showError(errorUI, error.message);
  }
};

const getWinningNumbers = () => {
  const winningNumberInput = Array.from($all('.winning-form__number-box'))
    .map((input) => input.value.trim())
    .filter((value) => value !== '');

  const bonusNumberInput = $('.winning-form__bonus-number').value.trim();

  validateWinningNumber(winningNumberInput);
  const winningNumbers = parseWinningNumber(winningNumberInput);

  validateBonusNumber(winningNumbers, bonusNumberInput);
  const bonusNumber = parseBonusNumber(bonusNumberInput);

  return { winningNumbers, bonusNumber };
};
